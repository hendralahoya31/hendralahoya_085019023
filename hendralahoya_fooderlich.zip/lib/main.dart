import 'package:flutter/material.dart';
import 'package:flutterapp/hendralahoya_fooderlichapp/generatediphone83widget/GeneratedIPhone83Widget.dart';
import 'package:flutterapp/hendralahoya_fooderlichapp/generatediphone82widget/GeneratedIPhone82Widget.dart';
import 'package:flutterapp/hendralahoya_fooderlichapp/generatediphone81widget/GeneratedIPhone81Widget.dart';

void main() {
  runApp(hendralahoya_fooderlichApp());
}

class hendralahoya_fooderlichApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedIPhone81Widget',
      routes: {
        '/GeneratedIPhone83Widget': (context) => GeneratedIPhone83Widget(),
        '/GeneratedIPhone82Widget': (context) => GeneratedIPhone82Widget(),
        '/GeneratedIPhone81Widget': (context) => GeneratedIPhone81Widget(),
      },
    );
  }
}
